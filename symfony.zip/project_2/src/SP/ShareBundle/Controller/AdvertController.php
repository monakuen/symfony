<?php
/**
 * Created by PhpStorm.
 * User: jerome
 * Date: 9/11/17
 * Time: 15:31
 */

namespace SP\ShareBundle\Controller;

// N'oubliez pas ce use :
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
//use OC\PlatformBundle\Entity\Advert;
//use OC\PlatformBundle\Entity\Image;
//use OC\PlatformBundle\Entity\Application;

class AdvertController extends Controller
{
    public function indexAction($page)
    {
        if($page<1){
            throw new NotFoundHttpException("la page ".$page." est inexistante");
        }

        return new Response("Notre propre Hello World !");


    }
}