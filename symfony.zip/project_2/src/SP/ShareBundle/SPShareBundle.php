<?php

namespace SP\ShareBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SPShareBundle extends Bundle
{
}
