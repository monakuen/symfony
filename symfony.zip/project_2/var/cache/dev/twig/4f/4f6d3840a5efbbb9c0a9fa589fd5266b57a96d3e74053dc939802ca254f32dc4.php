<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_8006b7f8fc2624f01b3de6d52decc5ff3e8fa8050fc8435cce232d4e154540ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d00f6ac86808a4a2790ca7e4f83691bd6a551f4ddd2d2a080bccac823596d0f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d00f6ac86808a4a2790ca7e4f83691bd6a551f4ddd2d2a080bccac823596d0f6->enter($__internal_d00f6ac86808a4a2790ca7e4f83691bd6a551f4ddd2d2a080bccac823596d0f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_a40e3fae6085501357ff792af22a85c0ed509f36e7bdd649ac0d64bd04b63fb8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a40e3fae6085501357ff792af22a85c0ed509f36e7bdd649ac0d64bd04b63fb8->enter($__internal_a40e3fae6085501357ff792af22a85c0ed509f36e7bdd649ac0d64bd04b63fb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d00f6ac86808a4a2790ca7e4f83691bd6a551f4ddd2d2a080bccac823596d0f6->leave($__internal_d00f6ac86808a4a2790ca7e4f83691bd6a551f4ddd2d2a080bccac823596d0f6_prof);

        
        $__internal_a40e3fae6085501357ff792af22a85c0ed509f36e7bdd649ac0d64bd04b63fb8->leave($__internal_a40e3fae6085501357ff792af22a85c0ed509f36e7bdd649ac0d64bd04b63fb8_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_88a042003d3e7cdceb64855d3c1c12aec368f0bf4f41dd19eaef4fdf59202c39 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88a042003d3e7cdceb64855d3c1c12aec368f0bf4f41dd19eaef4fdf59202c39->enter($__internal_88a042003d3e7cdceb64855d3c1c12aec368f0bf4f41dd19eaef4fdf59202c39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_879e1f6d3e93deb7be1002ccfa6407770e49c283c72c9dc567d0ce6c6fa3c534 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_879e1f6d3e93deb7be1002ccfa6407770e49c283c72c9dc567d0ce6c6fa3c534->enter($__internal_879e1f6d3e93deb7be1002ccfa6407770e49c283c72c9dc567d0ce6c6fa3c534_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_879e1f6d3e93deb7be1002ccfa6407770e49c283c72c9dc567d0ce6c6fa3c534->leave($__internal_879e1f6d3e93deb7be1002ccfa6407770e49c283c72c9dc567d0ce6c6fa3c534_prof);

        
        $__internal_88a042003d3e7cdceb64855d3c1c12aec368f0bf4f41dd19eaef4fdf59202c39->leave($__internal_88a042003d3e7cdceb64855d3c1c12aec368f0bf4f41dd19eaef4fdf59202c39_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_60fc3aa3c8416b4bbdfeae056bb102e04294e285ea3198ba27194c9fb29f771b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_60fc3aa3c8416b4bbdfeae056bb102e04294e285ea3198ba27194c9fb29f771b->enter($__internal_60fc3aa3c8416b4bbdfeae056bb102e04294e285ea3198ba27194c9fb29f771b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_9e7986c901450e06ac32253e2ac30e11e753b7417a9a7872d18336301fd2fd3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e7986c901450e06ac32253e2ac30e11e753b7417a9a7872d18336301fd2fd3d->enter($__internal_9e7986c901450e06ac32253e2ac30e11e753b7417a9a7872d18336301fd2fd3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_9e7986c901450e06ac32253e2ac30e11e753b7417a9a7872d18336301fd2fd3d->leave($__internal_9e7986c901450e06ac32253e2ac30e11e753b7417a9a7872d18336301fd2fd3d_prof);

        
        $__internal_60fc3aa3c8416b4bbdfeae056bb102e04294e285ea3198ba27194c9fb29f771b->leave($__internal_60fc3aa3c8416b4bbdfeae056bb102e04294e285ea3198ba27194c9fb29f771b_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_7aa27047de3c47a1e5c569c72167b41e196820a0d5a772d7ad634d87e3e55b64 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7aa27047de3c47a1e5c569c72167b41e196820a0d5a772d7ad634d87e3e55b64->enter($__internal_7aa27047de3c47a1e5c569c72167b41e196820a0d5a772d7ad634d87e3e55b64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_47d0930b7bfd6922561abee02e38f72682ee9a7958e1fbcca367c1077b0e6c36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47d0930b7bfd6922561abee02e38f72682ee9a7958e1fbcca367c1077b0e6c36->enter($__internal_47d0930b7bfd6922561abee02e38f72682ee9a7958e1fbcca367c1077b0e6c36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_47d0930b7bfd6922561abee02e38f72682ee9a7958e1fbcca367c1077b0e6c36->leave($__internal_47d0930b7bfd6922561abee02e38f72682ee9a7958e1fbcca367c1077b0e6c36_prof);

        
        $__internal_7aa27047de3c47a1e5c569c72167b41e196820a0d5a772d7ad634d87e3e55b64->leave($__internal_7aa27047de3c47a1e5c569c72167b41e196820a0d5a772d7ad634d87e3e55b64_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/home/jerome/symfony/project_2/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
