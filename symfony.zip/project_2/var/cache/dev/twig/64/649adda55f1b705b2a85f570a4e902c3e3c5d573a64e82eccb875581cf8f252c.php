<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_6c775e4c4ccdb3af11f3aa2031a382d5c0ed87f26f326c1f292fdbc62fcd4060 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3cdb1533e6ba823254ae99ea582300b66db54c56b173307b4cb138672a91222d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3cdb1533e6ba823254ae99ea582300b66db54c56b173307b4cb138672a91222d->enter($__internal_3cdb1533e6ba823254ae99ea582300b66db54c56b173307b4cb138672a91222d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_7dff206be3150bcb8f46bc15aab75580a6bb903db883b3cae0069605584a0392 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7dff206be3150bcb8f46bc15aab75580a6bb903db883b3cae0069605584a0392->enter($__internal_7dff206be3150bcb8f46bc15aab75580a6bb903db883b3cae0069605584a0392_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3cdb1533e6ba823254ae99ea582300b66db54c56b173307b4cb138672a91222d->leave($__internal_3cdb1533e6ba823254ae99ea582300b66db54c56b173307b4cb138672a91222d_prof);

        
        $__internal_7dff206be3150bcb8f46bc15aab75580a6bb903db883b3cae0069605584a0392->leave($__internal_7dff206be3150bcb8f46bc15aab75580a6bb903db883b3cae0069605584a0392_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_a0cfd47ffa71f27a681486648586b929e4aaf6995fc68c9dbfdcb3cc6dca8e8a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0cfd47ffa71f27a681486648586b929e4aaf6995fc68c9dbfdcb3cc6dca8e8a->enter($__internal_a0cfd47ffa71f27a681486648586b929e4aaf6995fc68c9dbfdcb3cc6dca8e8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_1864d0d03054b48d05692c16b27c7a8ad254948c1d37fec0844c904e930f2afb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1864d0d03054b48d05692c16b27c7a8ad254948c1d37fec0844c904e930f2afb->enter($__internal_1864d0d03054b48d05692c16b27c7a8ad254948c1d37fec0844c904e930f2afb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_1864d0d03054b48d05692c16b27c7a8ad254948c1d37fec0844c904e930f2afb->leave($__internal_1864d0d03054b48d05692c16b27c7a8ad254948c1d37fec0844c904e930f2afb_prof);

        
        $__internal_a0cfd47ffa71f27a681486648586b929e4aaf6995fc68c9dbfdcb3cc6dca8e8a->leave($__internal_a0cfd47ffa71f27a681486648586b929e4aaf6995fc68c9dbfdcb3cc6dca8e8a_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_6a522ad83d02060add5b7689a471f262c4300200082d6a7bf54ab7f1a7193de6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a522ad83d02060add5b7689a471f262c4300200082d6a7bf54ab7f1a7193de6->enter($__internal_6a522ad83d02060add5b7689a471f262c4300200082d6a7bf54ab7f1a7193de6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_075687c5cafd6594409485afa231f71bad9f98b47c69933469327a79f1746a9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_075687c5cafd6594409485afa231f71bad9f98b47c69933469327a79f1746a9d->enter($__internal_075687c5cafd6594409485afa231f71bad9f98b47c69933469327a79f1746a9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_075687c5cafd6594409485afa231f71bad9f98b47c69933469327a79f1746a9d->leave($__internal_075687c5cafd6594409485afa231f71bad9f98b47c69933469327a79f1746a9d_prof);

        
        $__internal_6a522ad83d02060add5b7689a471f262c4300200082d6a7bf54ab7f1a7193de6->leave($__internal_6a522ad83d02060add5b7689a471f262c4300200082d6a7bf54ab7f1a7193de6_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_973185933e8c623c80961d5699566438f5857ec38c28cd3c2847711442b382c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_973185933e8c623c80961d5699566438f5857ec38c28cd3c2847711442b382c1->enter($__internal_973185933e8c623c80961d5699566438f5857ec38c28cd3c2847711442b382c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_cc5ced01e30186c420470a4e541ac0171997ae3128406e30f6fdcb919da42367 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc5ced01e30186c420470a4e541ac0171997ae3128406e30f6fdcb919da42367->enter($__internal_cc5ced01e30186c420470a4e541ac0171997ae3128406e30f6fdcb919da42367_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_cc5ced01e30186c420470a4e541ac0171997ae3128406e30f6fdcb919da42367->leave($__internal_cc5ced01e30186c420470a4e541ac0171997ae3128406e30f6fdcb919da42367_prof);

        
        $__internal_973185933e8c623c80961d5699566438f5857ec38c28cd3c2847711442b382c1->leave($__internal_973185933e8c623c80961d5699566438f5857ec38c28cd3c2847711442b382c1_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/jerome/symfony/project_2/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
