<?php

/* base.html.twig */
class __TwigTemplate_ef6a598e82a5011af52d5b328f0cd2f8830bea5f4c88506ad9e23671aec9697a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a495a2df1597d01742346ccfeaecfe62dd3a1b269a80acf44f10b4ffd14dcdae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a495a2df1597d01742346ccfeaecfe62dd3a1b269a80acf44f10b4ffd14dcdae->enter($__internal_a495a2df1597d01742346ccfeaecfe62dd3a1b269a80acf44f10b4ffd14dcdae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_54ed0696f18fd8c9a863dc39f7b499ce2dec7ca3264ae73a7b7883822591eba1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54ed0696f18fd8c9a863dc39f7b499ce2dec7ca3264ae73a7b7883822591eba1->enter($__internal_54ed0696f18fd8c9a863dc39f7b499ce2dec7ca3264ae73a7b7883822591eba1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_a495a2df1597d01742346ccfeaecfe62dd3a1b269a80acf44f10b4ffd14dcdae->leave($__internal_a495a2df1597d01742346ccfeaecfe62dd3a1b269a80acf44f10b4ffd14dcdae_prof);

        
        $__internal_54ed0696f18fd8c9a863dc39f7b499ce2dec7ca3264ae73a7b7883822591eba1->leave($__internal_54ed0696f18fd8c9a863dc39f7b499ce2dec7ca3264ae73a7b7883822591eba1_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_f23c172f73893f531ac662c60208d3c1937547c88e45e90a45251fb95b4690ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f23c172f73893f531ac662c60208d3c1937547c88e45e90a45251fb95b4690ed->enter($__internal_f23c172f73893f531ac662c60208d3c1937547c88e45e90a45251fb95b4690ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_780bb1daebf5a4666a6ab25910de2c1e7d94fe3a59944576e811d2c2d86ea240 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_780bb1daebf5a4666a6ab25910de2c1e7d94fe3a59944576e811d2c2d86ea240->enter($__internal_780bb1daebf5a4666a6ab25910de2c1e7d94fe3a59944576e811d2c2d86ea240_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_780bb1daebf5a4666a6ab25910de2c1e7d94fe3a59944576e811d2c2d86ea240->leave($__internal_780bb1daebf5a4666a6ab25910de2c1e7d94fe3a59944576e811d2c2d86ea240_prof);

        
        $__internal_f23c172f73893f531ac662c60208d3c1937547c88e45e90a45251fb95b4690ed->leave($__internal_f23c172f73893f531ac662c60208d3c1937547c88e45e90a45251fb95b4690ed_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e0d9e5ee72ffbb0db2029e3b8ce470ca477ec91244dfe511a299b7a593456880 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0d9e5ee72ffbb0db2029e3b8ce470ca477ec91244dfe511a299b7a593456880->enter($__internal_e0d9e5ee72ffbb0db2029e3b8ce470ca477ec91244dfe511a299b7a593456880_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8544d5d5659442c0c5c49f83c5daa38a1f2a7ed3cf7f87c10fa32ab7846410ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8544d5d5659442c0c5c49f83c5daa38a1f2a7ed3cf7f87c10fa32ab7846410ee->enter($__internal_8544d5d5659442c0c5c49f83c5daa38a1f2a7ed3cf7f87c10fa32ab7846410ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_8544d5d5659442c0c5c49f83c5daa38a1f2a7ed3cf7f87c10fa32ab7846410ee->leave($__internal_8544d5d5659442c0c5c49f83c5daa38a1f2a7ed3cf7f87c10fa32ab7846410ee_prof);

        
        $__internal_e0d9e5ee72ffbb0db2029e3b8ce470ca477ec91244dfe511a299b7a593456880->leave($__internal_e0d9e5ee72ffbb0db2029e3b8ce470ca477ec91244dfe511a299b7a593456880_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_4a6b712056f5ddb2dbf671296745a35023eed802c0bb5a76fc76dae88e0eb309 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4a6b712056f5ddb2dbf671296745a35023eed802c0bb5a76fc76dae88e0eb309->enter($__internal_4a6b712056f5ddb2dbf671296745a35023eed802c0bb5a76fc76dae88e0eb309_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0aa59595a6e81a8340a23f77d5698cfc78c9220fc28dc693d24b52c1833da246 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0aa59595a6e81a8340a23f77d5698cfc78c9220fc28dc693d24b52c1833da246->enter($__internal_0aa59595a6e81a8340a23f77d5698cfc78c9220fc28dc693d24b52c1833da246_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0aa59595a6e81a8340a23f77d5698cfc78c9220fc28dc693d24b52c1833da246->leave($__internal_0aa59595a6e81a8340a23f77d5698cfc78c9220fc28dc693d24b52c1833da246_prof);

        
        $__internal_4a6b712056f5ddb2dbf671296745a35023eed802c0bb5a76fc76dae88e0eb309->leave($__internal_4a6b712056f5ddb2dbf671296745a35023eed802c0bb5a76fc76dae88e0eb309_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1c2a1018f1eede888dce0b1bc2e34277924ec0e808cb3fcf601ee89aab0fd3b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c2a1018f1eede888dce0b1bc2e34277924ec0e808cb3fcf601ee89aab0fd3b4->enter($__internal_1c2a1018f1eede888dce0b1bc2e34277924ec0e808cb3fcf601ee89aab0fd3b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_66744b703bfae66260ba0a460e78f16267f30f56bacbd0ac1161cfe6e7c9f624 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66744b703bfae66260ba0a460e78f16267f30f56bacbd0ac1161cfe6e7c9f624->enter($__internal_66744b703bfae66260ba0a460e78f16267f30f56bacbd0ac1161cfe6e7c9f624_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_66744b703bfae66260ba0a460e78f16267f30f56bacbd0ac1161cfe6e7c9f624->leave($__internal_66744b703bfae66260ba0a460e78f16267f30f56bacbd0ac1161cfe6e7c9f624_prof);

        
        $__internal_1c2a1018f1eede888dce0b1bc2e34277924ec0e808cb3fcf601ee89aab0fd3b4->leave($__internal_1c2a1018f1eede888dce0b1bc2e34277924ec0e808cb3fcf601ee89aab0fd3b4_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/home/jerome/symfony/project_2/app/Resources/views/base.html.twig");
    }
}
