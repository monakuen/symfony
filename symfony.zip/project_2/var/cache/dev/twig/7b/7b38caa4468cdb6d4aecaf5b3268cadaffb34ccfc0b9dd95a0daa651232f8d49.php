<?php

/* SPShareBundle:Default:index.html.twig */
class __TwigTemplate_9c011088d30ccef00a32221ea582cd5542ea1f4992dd95b89c7ee69cb7542bf3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a14209fee4859ea9f0ddbb93f82cf08331167828e5afb5f9c154d15f3a313cc4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a14209fee4859ea9f0ddbb93f82cf08331167828e5afb5f9c154d15f3a313cc4->enter($__internal_a14209fee4859ea9f0ddbb93f82cf08331167828e5afb5f9c154d15f3a313cc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SPShareBundle:Default:index.html.twig"));

        $__internal_b1f56765db947af89d13e80c485c49aad3e7f19fa9e156403ff692fd692f3a10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1f56765db947af89d13e80c485c49aad3e7f19fa9e156403ff692fd692f3a10->enter($__internal_b1f56765db947af89d13e80c485c49aad3e7f19fa9e156403ff692fd692f3a10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SPShareBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_a14209fee4859ea9f0ddbb93f82cf08331167828e5afb5f9c154d15f3a313cc4->leave($__internal_a14209fee4859ea9f0ddbb93f82cf08331167828e5afb5f9c154d15f3a313cc4_prof);

        
        $__internal_b1f56765db947af89d13e80c485c49aad3e7f19fa9e156403ff692fd692f3a10->leave($__internal_b1f56765db947af89d13e80c485c49aad3e7f19fa9e156403ff692fd692f3a10_prof);

    }

    public function getTemplateName()
    {
        return "SPShareBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!
", "SPShareBundle:Default:index.html.twig", "/home/jerome/symfony/project_2/src/SP/ShareBundle/Resources/views/Default/index.html.twig");
    }
}
