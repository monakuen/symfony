<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_504b4c769556d0dec363c5a1ba46cd1ccd966e1af8d1a9aa5a5f438d60d29ae7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0781fa2922af99f295594818f1ec424bcdeedc465962bfedb3e30d4d676d5ddd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0781fa2922af99f295594818f1ec424bcdeedc465962bfedb3e30d4d676d5ddd->enter($__internal_0781fa2922af99f295594818f1ec424bcdeedc465962bfedb3e30d4d676d5ddd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_576843243fff554f0200bc78f221cab081c33f04d7a4005273b6dd3f66995bee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_576843243fff554f0200bc78f221cab081c33f04d7a4005273b6dd3f66995bee->enter($__internal_576843243fff554f0200bc78f221cab081c33f04d7a4005273b6dd3f66995bee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0781fa2922af99f295594818f1ec424bcdeedc465962bfedb3e30d4d676d5ddd->leave($__internal_0781fa2922af99f295594818f1ec424bcdeedc465962bfedb3e30d4d676d5ddd_prof);

        
        $__internal_576843243fff554f0200bc78f221cab081c33f04d7a4005273b6dd3f66995bee->leave($__internal_576843243fff554f0200bc78f221cab081c33f04d7a4005273b6dd3f66995bee_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_0fe24d666dcb6c4a479db0f2ae615d96e7ed40bb52f0e8a6e82849c0c41421be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0fe24d666dcb6c4a479db0f2ae615d96e7ed40bb52f0e8a6e82849c0c41421be->enter($__internal_0fe24d666dcb6c4a479db0f2ae615d96e7ed40bb52f0e8a6e82849c0c41421be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_04abb93cabbe7e39a2e280442a5b3e0ab0b3872256b9ea1ee29e4e22ef38ef9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04abb93cabbe7e39a2e280442a5b3e0ab0b3872256b9ea1ee29e4e22ef38ef9b->enter($__internal_04abb93cabbe7e39a2e280442a5b3e0ab0b3872256b9ea1ee29e4e22ef38ef9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_04abb93cabbe7e39a2e280442a5b3e0ab0b3872256b9ea1ee29e4e22ef38ef9b->leave($__internal_04abb93cabbe7e39a2e280442a5b3e0ab0b3872256b9ea1ee29e4e22ef38ef9b_prof);

        
        $__internal_0fe24d666dcb6c4a479db0f2ae615d96e7ed40bb52f0e8a6e82849c0c41421be->leave($__internal_0fe24d666dcb6c4a479db0f2ae615d96e7ed40bb52f0e8a6e82849c0c41421be_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ca53409f87a05fae42c9afd9ccb903b7819b052ef8818c7f41e4b40eb4ca38aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca53409f87a05fae42c9afd9ccb903b7819b052ef8818c7f41e4b40eb4ca38aa->enter($__internal_ca53409f87a05fae42c9afd9ccb903b7819b052ef8818c7f41e4b40eb4ca38aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_67cd0b27ec9226a1ac856773fed9e5a8cfee545460eae4b42df553e40c9467ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67cd0b27ec9226a1ac856773fed9e5a8cfee545460eae4b42df553e40c9467ea->enter($__internal_67cd0b27ec9226a1ac856773fed9e5a8cfee545460eae4b42df553e40c9467ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_67cd0b27ec9226a1ac856773fed9e5a8cfee545460eae4b42df553e40c9467ea->leave($__internal_67cd0b27ec9226a1ac856773fed9e5a8cfee545460eae4b42df553e40c9467ea_prof);

        
        $__internal_ca53409f87a05fae42c9afd9ccb903b7819b052ef8818c7f41e4b40eb4ca38aa->leave($__internal_ca53409f87a05fae42c9afd9ccb903b7819b052ef8818c7f41e4b40eb4ca38aa_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_40ef79667ff596ad5ebcb16598ac592a4b54bc5aaee58d5a8bb7ba407ab0bcbb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40ef79667ff596ad5ebcb16598ac592a4b54bc5aaee58d5a8bb7ba407ab0bcbb->enter($__internal_40ef79667ff596ad5ebcb16598ac592a4b54bc5aaee58d5a8bb7ba407ab0bcbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_7bdc05ad103128395ba387d91c7ba2d44cc2e7d1ad69095166a655513548a1f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7bdc05ad103128395ba387d91c7ba2d44cc2e7d1ad69095166a655513548a1f0->enter($__internal_7bdc05ad103128395ba387d91c7ba2d44cc2e7d1ad69095166a655513548a1f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_7bdc05ad103128395ba387d91c7ba2d44cc2e7d1ad69095166a655513548a1f0->leave($__internal_7bdc05ad103128395ba387d91c7ba2d44cc2e7d1ad69095166a655513548a1f0_prof);

        
        $__internal_40ef79667ff596ad5ebcb16598ac592a4b54bc5aaee58d5a8bb7ba407ab0bcbb->leave($__internal_40ef79667ff596ad5ebcb16598ac592a4b54bc5aaee58d5a8bb7ba407ab0bcbb_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/jerome/symfony/project_2/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
