<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_4fe0126cea834c2021a568bc22188a6a6babe007ed6f1aff9514e87b8ba11595 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c15d93bfe3904c8dd01897d3bd8560ac9c3901ba7e30589ec98265a0983fe246 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c15d93bfe3904c8dd01897d3bd8560ac9c3901ba7e30589ec98265a0983fe246->enter($__internal_c15d93bfe3904c8dd01897d3bd8560ac9c3901ba7e30589ec98265a0983fe246_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_eb98c935109f7cb899561a55695bc8047ecb2fad6ec0305795d390d8a1bc8152 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb98c935109f7cb899561a55695bc8047ecb2fad6ec0305795d390d8a1bc8152->enter($__internal_eb98c935109f7cb899561a55695bc8047ecb2fad6ec0305795d390d8a1bc8152_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c15d93bfe3904c8dd01897d3bd8560ac9c3901ba7e30589ec98265a0983fe246->leave($__internal_c15d93bfe3904c8dd01897d3bd8560ac9c3901ba7e30589ec98265a0983fe246_prof);

        
        $__internal_eb98c935109f7cb899561a55695bc8047ecb2fad6ec0305795d390d8a1bc8152->leave($__internal_eb98c935109f7cb899561a55695bc8047ecb2fad6ec0305795d390d8a1bc8152_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a0daf001e8486682d99ee3133fdc0eb0b0888b957754fbb4edb368e54b683c5d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0daf001e8486682d99ee3133fdc0eb0b0888b957754fbb4edb368e54b683c5d->enter($__internal_a0daf001e8486682d99ee3133fdc0eb0b0888b957754fbb4edb368e54b683c5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_501f81835748a6674318133a0b7673deca732c79d03145b324086baa87aa812f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_501f81835748a6674318133a0b7673deca732c79d03145b324086baa87aa812f->enter($__internal_501f81835748a6674318133a0b7673deca732c79d03145b324086baa87aa812f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_501f81835748a6674318133a0b7673deca732c79d03145b324086baa87aa812f->leave($__internal_501f81835748a6674318133a0b7673deca732c79d03145b324086baa87aa812f_prof);

        
        $__internal_a0daf001e8486682d99ee3133fdc0eb0b0888b957754fbb4edb368e54b683c5d->leave($__internal_a0daf001e8486682d99ee3133fdc0eb0b0888b957754fbb4edb368e54b683c5d_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_d56b31ddcd2028f43c73aec7d3f22db62a70027846914d3a673d36cc850b4d82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d56b31ddcd2028f43c73aec7d3f22db62a70027846914d3a673d36cc850b4d82->enter($__internal_d56b31ddcd2028f43c73aec7d3f22db62a70027846914d3a673d36cc850b4d82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6d63668a61976c0666c10e0b1a876c5952a2dcd4ca72105c08b7a10130672f84 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d63668a61976c0666c10e0b1a876c5952a2dcd4ca72105c08b7a10130672f84->enter($__internal_6d63668a61976c0666c10e0b1a876c5952a2dcd4ca72105c08b7a10130672f84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 137, $this->getSourceContext()); })()), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 137, $this->getSourceContext()); })()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 137, $this->getSourceContext()); })()), "html", null, true);
        echo ")
";
        
        $__internal_6d63668a61976c0666c10e0b1a876c5952a2dcd4ca72105c08b7a10130672f84->leave($__internal_6d63668a61976c0666c10e0b1a876c5952a2dcd4ca72105c08b7a10130672f84_prof);

        
        $__internal_d56b31ddcd2028f43c73aec7d3f22db62a70027846914d3a673d36cc850b4d82->leave($__internal_d56b31ddcd2028f43c73aec7d3f22db62a70027846914d3a673d36cc850b4d82_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_370e78690219f75956bdcea3d30ab8143c85362e72602bd34ed525f1aadcb07b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_370e78690219f75956bdcea3d30ab8143c85362e72602bd34ed525f1aadcb07b->enter($__internal_370e78690219f75956bdcea3d30ab8143c85362e72602bd34ed525f1aadcb07b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_466a3d7b3bcb28fee716bb1a12691849a9a5f25b9c082b84a8e5d778652761dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_466a3d7b3bcb28fee716bb1a12691849a9a5f25b9c082b84a8e5d778652761dd->enter($__internal_466a3d7b3bcb28fee716bb1a12691849a9a5f25b9c082b84a8e5d778652761dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_466a3d7b3bcb28fee716bb1a12691849a9a5f25b9c082b84a8e5d778652761dd->leave($__internal_466a3d7b3bcb28fee716bb1a12691849a9a5f25b9c082b84a8e5d778652761dd_prof);

        
        $__internal_370e78690219f75956bdcea3d30ab8143c85362e72602bd34ed525f1aadcb07b->leave($__internal_370e78690219f75956bdcea3d30ab8143c85362e72602bd34ed525f1aadcb07b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "/home/jerome/symfony/project_2/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
