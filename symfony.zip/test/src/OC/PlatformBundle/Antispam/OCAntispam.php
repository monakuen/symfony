<?php
/**
 * Created by PhpStorm.
 * User: jerome
 * Date: 26/10/17
 * Time: 11:40
 */

namespace OC\PlatformBundle\Antispam;


class OCAntispam
{
    /**
     * @var OCAntispamMailer
     */
    private $spamMailer;
    /**
     * @var integer
     */
    private $minLength;

    /**
     * OCAntispam constructor.
     * @param OCAntispamMailer $spamMailer
     * @param int $minLength
     */
    public function __construct(OCAntispamMailer $spamMailer, $minLength)
    {
        $this->spamMailer = $spamMailer;
        $this->minLength = $minLength;
    }

    public function isSpam($text,$autoSendMail = false){
        $isSpam = strlen($text)>$this->minLength;
        if ($isSpam && $autoSendMail){
            $this->spamMailer->sendMailForSpamDetected($text);
        }

        return $isSpam;
    }
}