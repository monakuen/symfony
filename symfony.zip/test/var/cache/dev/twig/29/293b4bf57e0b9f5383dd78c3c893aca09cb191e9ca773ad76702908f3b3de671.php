<?php

/* ::layout.html.twig */
class __TwigTemplate_f1282e0934be0126d3f59c38709e8ff1c62cdecfa89e4cdd59af770144af35ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1d12299a12f61e7fcca02c89c678cdb0900749fdb74154c9882f75a99970d01d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d12299a12f61e7fcca02c89c678cdb0900749fdb74154c9882f75a99970d01d->enter($__internal_1d12299a12f61e7fcca02c89c678cdb0900749fdb74154c9882f75a99970d01d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        $__internal_19394c04327c9f3f5195d8c8f9881cd439fad2947407e45871f125163d5ffd94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19394c04327c9f3f5195d8c8f9881cd439fad2947407e45871f125163d5ffd94->enter($__internal_19394c04327c9f3f5195d8c8f9881cd439fad2947407e45871f125163d5ffd94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        // line 2
        echo "
<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 15
        echo "</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Les annonces</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\">Accueil</a></li>
                <li><a href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_add");
        echo "\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            ";
        // line 41
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("OCPlatformBundle:Advert:menu", array("limit" => 3)));
        echo "
        </div>
        <div id=\"content\" class=\"col-md-9\">
            ";
        // line 44
        $this->displayBlock('body', $context, $blocks);
        // line 46
        echo "        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © ";
        // line 52
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " and beyond.</p>
    </footer>
</div>

";
        // line 56
        $this->displayBlock('javascripts', $context, $blocks);
        // line 61
        echo "
</body>
</html>";
        
        $__internal_1d12299a12f61e7fcca02c89c678cdb0900749fdb74154c9882f75a99970d01d->leave($__internal_1d12299a12f61e7fcca02c89c678cdb0900749fdb74154c9882f75a99970d01d_prof);

        
        $__internal_19394c04327c9f3f5195d8c8f9881cd439fad2947407e45871f125163d5ffd94->leave($__internal_19394c04327c9f3f5195d8c8f9881cd439fad2947407e45871f125163d5ffd94_prof);

    }

    // line 9
    public function block_title($context, array $blocks = array())
    {
        $__internal_1c92296efcba237abf50bb8d3feb0f7f065e83a0bd1a8dd8327d1fb3a51eee4b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c92296efcba237abf50bb8d3feb0f7f065e83a0bd1a8dd8327d1fb3a51eee4b->enter($__internal_1c92296efcba237abf50bb8d3feb0f7f065e83a0bd1a8dd8327d1fb3a51eee4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_deb225fd8b4a7f83b8d20c60ba8b904658dfa0d08287a5bd42b984eba466702d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_deb225fd8b4a7f83b8d20c60ba8b904658dfa0d08287a5bd42b984eba466702d->enter($__internal_deb225fd8b4a7f83b8d20c60ba8b904658dfa0d08287a5bd42b984eba466702d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "OC Plateforme";
        
        $__internal_deb225fd8b4a7f83b8d20c60ba8b904658dfa0d08287a5bd42b984eba466702d->leave($__internal_deb225fd8b4a7f83b8d20c60ba8b904658dfa0d08287a5bd42b984eba466702d_prof);

        
        $__internal_1c92296efcba237abf50bb8d3feb0f7f065e83a0bd1a8dd8327d1fb3a51eee4b->leave($__internal_1c92296efcba237abf50bb8d3feb0f7f065e83a0bd1a8dd8327d1fb3a51eee4b_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_73f83ef8ac0669a63ad5e3155379571c10f4ddd62a9244e83ddaf33e5a3782ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73f83ef8ac0669a63ad5e3155379571c10f4ddd62a9244e83ddaf33e5a3782ee->enter($__internal_73f83ef8ac0669a63ad5e3155379571c10f4ddd62a9244e83ddaf33e5a3782ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_102aee8bdf35cdd8b6d011c7c17bff020a0435b0e8fe1194e41987fe52755e99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_102aee8bdf35cdd8b6d011c7c17bff020a0435b0e8fe1194e41987fe52755e99->enter($__internal_102aee8bdf35cdd8b6d011c7c17bff020a0435b0e8fe1194e41987fe52755e99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 12
        echo "        ";
        // line 13
        echo "        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    ";
        
        $__internal_102aee8bdf35cdd8b6d011c7c17bff020a0435b0e8fe1194e41987fe52755e99->leave($__internal_102aee8bdf35cdd8b6d011c7c17bff020a0435b0e8fe1194e41987fe52755e99_prof);

        
        $__internal_73f83ef8ac0669a63ad5e3155379571c10f4ddd62a9244e83ddaf33e5a3782ee->leave($__internal_73f83ef8ac0669a63ad5e3155379571c10f4ddd62a9244e83ddaf33e5a3782ee_prof);

    }

    // line 44
    public function block_body($context, array $blocks = array())
    {
        $__internal_cc76487ececdd814a48d4d5b8d94147f24d0d1bee384016a21eb479fc6243928 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc76487ececdd814a48d4d5b8d94147f24d0d1bee384016a21eb479fc6243928->enter($__internal_cc76487ececdd814a48d4d5b8d94147f24d0d1bee384016a21eb479fc6243928_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e8f4023c39b1aebb813c4de816d9bf71475329660d96b932acd6a40ca2335297 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8f4023c39b1aebb813c4de816d9bf71475329660d96b932acd6a40ca2335297->enter($__internal_e8f4023c39b1aebb813c4de816d9bf71475329660d96b932acd6a40ca2335297_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 45
        echo "            ";
        
        $__internal_e8f4023c39b1aebb813c4de816d9bf71475329660d96b932acd6a40ca2335297->leave($__internal_e8f4023c39b1aebb813c4de816d9bf71475329660d96b932acd6a40ca2335297_prof);

        
        $__internal_cc76487ececdd814a48d4d5b8d94147f24d0d1bee384016a21eb479fc6243928->leave($__internal_cc76487ececdd814a48d4d5b8d94147f24d0d1bee384016a21eb479fc6243928_prof);

    }

    // line 56
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5cde77d188245c7a2310923ef886495973e8ef5b0c51daee84985aa15d22e002 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5cde77d188245c7a2310923ef886495973e8ef5b0c51daee84985aa15d22e002->enter($__internal_5cde77d188245c7a2310923ef886495973e8ef5b0c51daee84985aa15d22e002_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6be257b82b85aeccb2a0c63678d6a052e3bad52386b45648140442a35df5c3a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6be257b82b85aeccb2a0c63678d6a052e3bad52386b45648140442a35df5c3a8->enter($__internal_6be257b82b85aeccb2a0c63678d6a052e3bad52386b45648140442a35df5c3a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 57
        echo "    ";
        // line 58
        echo "    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
";
        
        $__internal_6be257b82b85aeccb2a0c63678d6a052e3bad52386b45648140442a35df5c3a8->leave($__internal_6be257b82b85aeccb2a0c63678d6a052e3bad52386b45648140442a35df5c3a8_prof);

        
        $__internal_5cde77d188245c7a2310923ef886495973e8ef5b0c51daee84985aa15d22e002->leave($__internal_5cde77d188245c7a2310923ef886495973e8ef5b0c51daee84985aa15d22e002_prof);

    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  186 => 58,  184 => 57,  175 => 56,  165 => 45,  156 => 44,  145 => 13,  143 => 12,  134 => 11,  116 => 9,  104 => 61,  102 => 56,  95 => 52,  87 => 46,  85 => 44,  79 => 41,  72 => 37,  68 => 36,  45 => 15,  43 => 11,  38 => 9,  29 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# app/Resources/views/layout.html.twig #}

<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>{% block title %}OC Plateforme{% endblock %}</title>

    {% block stylesheets %}
        {# On charge le CSS de bootstrap depuis le site directement #}
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\">
    {% endblock %}
</head>

<body>
<div class=\"container\">
    <div id=\"header\" class=\"jumbotron\">
        <h1>Ma plateforme d'annonces</h1>
        <p>
            Ce projet est propulsé par Symfony,
            et construit grâce au MOOC OpenClassrooms et SensioLabs.
        </p>
        <p>
            <a class=\"btn btn-primary btn-lg\" href=\"https://openclassrooms.com/courses/developpez-votre-site-web-avec-le-framework-symfony2\">
                Participer au MOOC »
            </a>
        </p>
    </div>

    <div class=\"row\">
        <div id=\"menu\" class=\"col-md-3\">
            <h3>Les annonces</h3>
            <ul class=\"nav nav-pills nav-stacked\">
                <li><a href=\"{{ path('oc_platform_home') }}\">Accueil</a></li>
                <li><a href=\"{{ path('oc_platform_add') }}\">Ajouter une annonce</a></li>
            </ul>

            <h4>Dernières annonces</h4>
            {{ render(controller(\"OCPlatformBundle:Advert:menu\", {'limit': 3})) }}
        </div>
        <div id=\"content\" class=\"col-md-9\">
            {% block body %}
            {% endblock %}
        </div>
    </div>

    <hr>

    <footer>
        <p>The sky's the limit © {{ 'now'|date('Y') }} and beyond.</p>
    </footer>
</div>

{% block javascripts %}
    {# Ajoutez ces lignes JavaScript si vous comptez vous servir des fonctionnalités du bootstrap Twitter #}
    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>
{% endblock %}

</body>
</html>", "::layout.html.twig", "/home/jerome/symfony/test/app/Resources/views/layout.html.twig");
    }
}
