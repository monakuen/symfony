<?php

/* OCPlatformBundle:Advert:view.html.twig */
class __TwigTemplate_7149131ab79eb8e209d566ce9d87cb86b6a3b9f36cd1c13aeb13bbb47fcbe7e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:view.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4038848e0c098d61f0132f625bdead3b83f30421e43a16df084f337bb1d7104a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4038848e0c098d61f0132f625bdead3b83f30421e43a16df084f337bb1d7104a->enter($__internal_4038848e0c098d61f0132f625bdead3b83f30421e43a16df084f337bb1d7104a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        $__internal_1c4fada3ab638bbfeba0c78b1582eca4f3d7b70e7fd30b1998f8c5f0e771dc7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c4fada3ab638bbfeba0c78b1582eca4f3d7b70e7fd30b1998f8c5f0e771dc7c->enter($__internal_1c4fada3ab638bbfeba0c78b1582eca4f3d7b70e7fd30b1998f8c5f0e771dc7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4038848e0c098d61f0132f625bdead3b83f30421e43a16df084f337bb1d7104a->leave($__internal_4038848e0c098d61f0132f625bdead3b83f30421e43a16df084f337bb1d7104a_prof);

        
        $__internal_1c4fada3ab638bbfeba0c78b1582eca4f3d7b70e7fd30b1998f8c5f0e771dc7c->leave($__internal_1c4fada3ab638bbfeba0c78b1582eca4f3d7b70e7fd30b1998f8c5f0e771dc7c_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_a58e204f297dab4c9d0c28f2bf3c4ea2d9ddb49cd941ea235d9af813f529ddaf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a58e204f297dab4c9d0c28f2bf3c4ea2d9ddb49cd941ea235d9af813f529ddaf->enter($__internal_a58e204f297dab4c9d0c28f2bf3c4ea2d9ddb49cd941ea235d9af813f529ddaf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_f7db8f61df02e0389a94df488eacb2de92714c08ac019731f5967ebe89ed40a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7db8f61df02e0389a94df488eacb2de92714c08ac019731f5967ebe89ed40a3->enter($__internal_f7db8f61df02e0389a94df488eacb2de92714c08ac019731f5967ebe89ed40a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    Lecture d'une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_f7db8f61df02e0389a94df488eacb2de92714c08ac019731f5967ebe89ed40a3->leave($__internal_f7db8f61df02e0389a94df488eacb2de92714c08ac019731f5967ebe89ed40a3_prof);

        
        $__internal_a58e204f297dab4c9d0c28f2bf3c4ea2d9ddb49cd941ea235d9af813f529ddaf->leave($__internal_a58e204f297dab4c9d0c28f2bf3c4ea2d9ddb49cd941ea235d9af813f529ddaf_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_2e08d91b84ef9496d3093b32db6b6338ada99e7c9d02d1f27fd4ebc52e924ea7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e08d91b84ef9496d3093b32db6b6338ada99e7c9d02d1f27fd4ebc52e924ea7->enter($__internal_2e08d91b84ef9496d3093b32db6b6338ada99e7c9d02d1f27fd4ebc52e924ea7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_ca58d121b132c8b8bc282af3509c77c30b8015cfcbf07f1bd9bf79103328ccf6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca58d121b132c8b8bc282af3509c77c30b8015cfcbf07f1bd9bf79103328ccf6->enter($__internal_ca58d121b132c8b8bc282af3509c77c30b8015cfcbf07f1bd9bf79103328ccf6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
    <h2>";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 11, $this->getSourceContext()); })()), "title", array()), "html", null, true);
        echo "</h2>
    <i>Par ";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 12, $this->getSourceContext()); })()), "author", array()), "html", null, true);
        echo ", le ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 12, $this->getSourceContext()); })()), "date", array()), "d/m/Y"), "html", null, true);
        echo "</i>

    <div class=\"well\">
        ";
        // line 15
        if ( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 15, $this->getSourceContext()); })()), "image", array()))) {
            // line 16
            echo "        <div class=\"col-md-4\">
            <img class=\"img-responsive\" src=\"";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 17, $this->getSourceContext()); })()), "image", array()), "url", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 17, $this->getSourceContext()); })()), "image", array()), "alt", array()), "html", null, true);
            echo "\">
        </div>
        <div class=\"col-md-8\">
            ";
        }
        // line 21
        echo "            ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 21, $this->getSourceContext()); })()), "content", array()), "html", null, true);
        echo "
            ";
        // line 22
        if ( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 22, $this->getSourceContext()); })()), "image", array()))) {
            // line 23
            echo "        </div>
        <div class=\"clearfix\"></div>
        ";
        }
        // line 26
        echo "    </div>

    ";
        // line 28
        if (twig_length_filter($this->env, (isset($context["listApplications"]) || array_key_exists("listApplications", $context) ? $context["listApplications"] : (function () { throw new Twig_Error_Runtime('Variable "listApplications" does not exist.', 28, $this->getSourceContext()); })()))) {
            // line 29
            echo "        <div>
            <h3>Candidatures</h3>
            <ul class=\"\">
                ";
            // line 32
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["listApplications"]) || array_key_exists("listApplications", $context) ? $context["listApplications"] : (function () { throw new Twig_Error_Runtime('Variable "listApplications" does not exist.', 32, $this->getSourceContext()); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["application"]) {
                // line 33
                echo "                    <li>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["application"], "author", array()), "html", null, true);
                echo " : ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["application"], "content", array()), "html", null, true);
                echo "</li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['application'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 35
            echo "            </ul>
        </div>
    ";
        }
        // line 38
        echo "
    <p>
        <a href=\"";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_home");
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à la liste
        </a>
        <a href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_edit", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 44, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-edit\"></i>
            Modifier l'annonce
        </a>
        <a href=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_delete", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["advert"]) || array_key_exists("advert", $context) ? $context["advert"] : (function () { throw new Twig_Error_Runtime('Variable "advert" does not exist.', 48, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-danger\">
            <i class=\"glyphicon glyphicon-trash\"></i>
            Supprimer l'annonce
        </a>
    </p>

";
        
        $__internal_ca58d121b132c8b8bc282af3509c77c30b8015cfcbf07f1bd9bf79103328ccf6->leave($__internal_ca58d121b132c8b8bc282af3509c77c30b8015cfcbf07f1bd9bf79103328ccf6_prof);

        
        $__internal_2e08d91b84ef9496d3093b32db6b6338ada99e7c9d02d1f27fd4ebc52e924ea7->leave($__internal_2e08d91b84ef9496d3093b32db6b6338ada99e7c9d02d1f27fd4ebc52e924ea7_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 48,  155 => 44,  148 => 40,  144 => 38,  139 => 35,  128 => 33,  124 => 32,  119 => 29,  117 => 28,  113 => 26,  108 => 23,  106 => 22,  101 => 21,  92 => 17,  89 => 16,  87 => 15,  79 => 12,  75 => 11,  72 => 10,  63 => 9,  50 => 6,  41 => 5,  11 => 3,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/view/Advert/view.html.twig #}

{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Lecture d'une annonce - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>{{ advert.title }}</h2>
    <i>Par {{ advert.author }}, le {{ advert.date|date('d/m/Y') }}</i>

    <div class=\"well\">
        {% if advert.image is not null %}
        <div class=\"col-md-4\">
            <img class=\"img-responsive\" src=\"{{ advert.image.url }}\" alt=\"{{ advert.image.alt }}\">
        </div>
        <div class=\"col-md-8\">
            {% endif %}
            {{ advert.content }}
            {% if advert.image is not null %}
        </div>
        <div class=\"clearfix\"></div>
        {% endif %}
    </div>

    {% if listApplications|length %}
        <div>
            <h3>Candidatures</h3>
            <ul class=\"\">
                {% for application in listApplications %}
                    <li>{{  application.author}} : {{ application.content }}</li>
                {% endfor %}
            </ul>
        </div>
    {% endif %}

    <p>
        <a href=\"{{ path('oc_platform_home') }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-chevron-left\"></i>
            Retour à la liste
        </a>
        <a href=\"{{ path('oc_platform_edit', {'id': advert.id}) }}\" class=\"btn btn-default\">
            <i class=\"glyphicon glyphicon-edit\"></i>
            Modifier l'annonce
        </a>
        <a href=\"{{ path('oc_platform_delete', {'id': advert.id}) }}\" class=\"btn btn-danger\">
            <i class=\"glyphicon glyphicon-trash\"></i>
            Supprimer l'annonce
        </a>
    </p>

{% endblock %}", "OCPlatformBundle:Advert:view.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/view.html.twig");
    }
}
