<?php

/* OCPlatformBundle:Advert:menu.html.twig */
class __TwigTemplate_75e979bc998ef07808c7a21e11b06ad4d49fdfb036dde10c881be9547ef3a4ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_767b3d908beeb5b150a00a025aa69f7d56e7a4f5b4557d636a67268a1db0c730 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_767b3d908beeb5b150a00a025aa69f7d56e7a4f5b4557d636a67268a1db0c730->enter($__internal_767b3d908beeb5b150a00a025aa69f7d56e7a4f5b4557d636a67268a1db0c730_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:menu.html.twig"));

        $__internal_04bb0cd646ee5784735135921facc41c7efeb81d58b99da18918c3507eae362f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04bb0cd646ee5784735135921facc41c7efeb81d58b99da18918c3507eae362f->enter($__internal_04bb0cd646ee5784735135921facc41c7efeb81d58b99da18918c3507eae362f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:menu.html.twig"));

        // line 2
        echo "
<ul class=\"nav nav-pills nav-stacked\">
    ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listAdverts"]) || array_key_exists("listAdverts", $context) ? $context["listAdverts"] : (function () { throw new Twig_Error_Runtime('Variable "listAdverts" does not exist.', 4, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["advert"]) {
            // line 5
            echo "        <li>
            <a href=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "id", array()))), "html", null, true);
            echo "\">
                ";
            // line 7
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "title", array()), "html", null, true);
            echo "
            </a>
        </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "</ul>";
        
        $__internal_767b3d908beeb5b150a00a025aa69f7d56e7a4f5b4557d636a67268a1db0c730->leave($__internal_767b3d908beeb5b150a00a025aa69f7d56e7a4f5b4557d636a67268a1db0c730_prof);

        
        $__internal_04bb0cd646ee5784735135921facc41c7efeb81d58b99da18918c3507eae362f->leave($__internal_04bb0cd646ee5784735135921facc41c7efeb81d58b99da18918c3507eae362f_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 11,  40 => 7,  36 => 6,  33 => 5,  29 => 4,  25 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/Advert/menu.html.twig #}

<ul class=\"nav nav-pills nav-stacked\">
    {% for advert in listAdverts %}
        <li>
            <a href=\"{{ path('oc_platform_view', {'id': advert.id}) }}\">
                {{ advert.title }}
            </a>
        </li>
    {% endfor %}
</ul>", "OCPlatformBundle:Advert:menu.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/menu.html.twig");
    }
}
