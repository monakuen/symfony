<?php

/* OCPlatformBundle::layout.html.twig */
class __TwigTemplate_6bb31e474177f4f32fe54330ae9a9083dd82f4af58f0c299ee90a2930fe9f51e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("::layout.html.twig", "OCPlatformBundle::layout.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a88d26a16b4b4ec746b87656fea1bff37c877094e5585ba172f5142c6dd2765c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a88d26a16b4b4ec746b87656fea1bff37c877094e5585ba172f5142c6dd2765c->enter($__internal_a88d26a16b4b4ec746b87656fea1bff37c877094e5585ba172f5142c6dd2765c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $__internal_0084c8c97680a6b1505f8779d5e90f5510580445939eab6ecd2e1d7dd473d11d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0084c8c97680a6b1505f8779d5e90f5510580445939eab6ecd2e1d7dd473d11d->enter($__internal_0084c8c97680a6b1505f8779d5e90f5510580445939eab6ecd2e1d7dd473d11d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a88d26a16b4b4ec746b87656fea1bff37c877094e5585ba172f5142c6dd2765c->leave($__internal_a88d26a16b4b4ec746b87656fea1bff37c877094e5585ba172f5142c6dd2765c_prof);

        
        $__internal_0084c8c97680a6b1505f8779d5e90f5510580445939eab6ecd2e1d7dd473d11d->leave($__internal_0084c8c97680a6b1505f8779d5e90f5510580445939eab6ecd2e1d7dd473d11d_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_ee98842041089edcc543592c187dbc26665fe896d02e13fa4286011d6f1b29dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee98842041089edcc543592c187dbc26665fe896d02e13fa4286011d6f1b29dc->enter($__internal_ee98842041089edcc543592c187dbc26665fe896d02e13fa4286011d6f1b29dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b685431428de3f5a6d59512aa4439f84added72b1315c8d7fa35636665d55d98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b685431428de3f5a6d59512aa4439f84added72b1315c8d7fa35636665d55d98->enter($__internal_b685431428de3f5a6d59512aa4439f84added72b1315c8d7fa35636665d55d98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    Annonces - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_b685431428de3f5a6d59512aa4439f84added72b1315c8d7fa35636665d55d98->leave($__internal_b685431428de3f5a6d59512aa4439f84added72b1315c8d7fa35636665d55d98_prof);

        
        $__internal_ee98842041089edcc543592c187dbc26665fe896d02e13fa4286011d6f1b29dc->leave($__internal_ee98842041089edcc543592c187dbc26665fe896d02e13fa4286011d6f1b29dc_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_0e52d3f1838eb004ab0363410e8fc287ed6b544c940a95567f70e0e8b69f3583 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e52d3f1838eb004ab0363410e8fc287ed6b544c940a95567f70e0e8b69f3583->enter($__internal_0e52d3f1838eb004ab0363410e8fc287ed6b544c940a95567f70e0e8b69f3583_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_81b621dade47d0000aae0c04bf16ed165a1b994692e7a4e04ff22ef14cd33a56 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81b621dade47d0000aae0c04bf16ed165a1b994692e7a4e04ff22ef14cd33a56->enter($__internal_81b621dade47d0000aae0c04bf16ed165a1b994692e7a4e04ff22ef14cd33a56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
    ";
        // line 12
        echo "    <h1>Annonces</h1>

    <hr>

    ";
        // line 17
        echo "    ";
        $this->displayBlock('ocplatform_body', $context, $blocks);
        // line 19
        echo "
";
        
        $__internal_81b621dade47d0000aae0c04bf16ed165a1b994692e7a4e04ff22ef14cd33a56->leave($__internal_81b621dade47d0000aae0c04bf16ed165a1b994692e7a4e04ff22ef14cd33a56_prof);

        
        $__internal_0e52d3f1838eb004ab0363410e8fc287ed6b544c940a95567f70e0e8b69f3583->leave($__internal_0e52d3f1838eb004ab0363410e8fc287ed6b544c940a95567f70e0e8b69f3583_prof);

    }

    // line 17
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_584e5a7044b074dbd7bb1d56a8bae53d968cca55f39caec4be429da1147a385d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_584e5a7044b074dbd7bb1d56a8bae53d968cca55f39caec4be429da1147a385d->enter($__internal_584e5a7044b074dbd7bb1d56a8bae53d968cca55f39caec4be429da1147a385d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_b278bb91773ccd36e77238306877c17f82eef693675dd07a292754fe9dc00814 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b278bb91773ccd36e77238306877c17f82eef693675dd07a292754fe9dc00814->enter($__internal_b278bb91773ccd36e77238306877c17f82eef693675dd07a292754fe9dc00814_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 18
        echo "    ";
        
        $__internal_b278bb91773ccd36e77238306877c17f82eef693675dd07a292754fe9dc00814->leave($__internal_b278bb91773ccd36e77238306877c17f82eef693675dd07a292754fe9dc00814_prof);

        
        $__internal_584e5a7044b074dbd7bb1d56a8bae53d968cca55f39caec4be429da1147a385d->leave($__internal_584e5a7044b074dbd7bb1d56a8bae53d968cca55f39caec4be429da1147a385d_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 18,  96 => 17,  85 => 19,  82 => 17,  76 => 12,  73 => 10,  64 => 9,  51 => 6,  42 => 5,  11 => 3,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/layout.html.twig #}

{% extends \"::layout.html.twig\" %}

{% block title %}
    Annonces - {{ parent() }}
{% endblock %}

{% block body %}

    {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}
    <h1>Annonces</h1>

    <hr>

    {# On définit un nouveau bloc, que les vues du bundle pourront remplir #}
    {% block ocplatform_body %}
    {% endblock %}

{% endblock %}", "OCPlatformBundle::layout.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/layout.html.twig");
    }
}
