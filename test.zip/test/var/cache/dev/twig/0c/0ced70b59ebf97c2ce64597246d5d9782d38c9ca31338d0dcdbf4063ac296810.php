<?php

/* OCPlatformBundle:Advert:add.html.twig */
class __TwigTemplate_7910e7ed111a101f7025a839ad4a6ecb53ffaf7a36566b2e038167421da78920 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2d6c9838e5f305b3000a41f466b834cdea8698541317ac2bf6551909e797c54b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2d6c9838e5f305b3000a41f466b834cdea8698541317ac2bf6551909e797c54b->enter($__internal_2d6c9838e5f305b3000a41f466b834cdea8698541317ac2bf6551909e797c54b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:add.html.twig"));

        $__internal_67deaa7b1644ec6b4bc62ccea1bb22628cca36522fd1a0caf65a287ad16b9c3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67deaa7b1644ec6b4bc62ccea1bb22628cca36522fd1a0caf65a287ad16b9c3f->enter($__internal_67deaa7b1644ec6b4bc62ccea1bb22628cca36522fd1a0caf65a287ad16b9c3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:add.html.twig"));

        // line 1
        echo "ceci est la page avec le formulaire pour ajouter une annonce";
        
        $__internal_2d6c9838e5f305b3000a41f466b834cdea8698541317ac2bf6551909e797c54b->leave($__internal_2d6c9838e5f305b3000a41f466b834cdea8698541317ac2bf6551909e797c54b_prof);

        
        $__internal_67deaa7b1644ec6b4bc62ccea1bb22628cca36522fd1a0caf65a287ad16b9c3f->leave($__internal_67deaa7b1644ec6b4bc62ccea1bb22628cca36522fd1a0caf65a287ad16b9c3f_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:add.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("ceci est la page avec le formulaire pour ajouter une annonce", "OCPlatformBundle:Advert:add.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/add.html.twig");
    }
}
