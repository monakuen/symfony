<?php

/* OCPlatformBundle:Advert:add.html.twig */
class __TwigTemplate_7f39091cf16c1a680dd4fa7967faa73b4dd0a3945e39d3df9bec5a6fe6115397 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:add.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_91e90bda0a7ca16f8cb5dddd19e462a189fbdbd0e089fe87d0536504b7fdfc59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_91e90bda0a7ca16f8cb5dddd19e462a189fbdbd0e089fe87d0536504b7fdfc59->enter($__internal_91e90bda0a7ca16f8cb5dddd19e462a189fbdbd0e089fe87d0536504b7fdfc59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:add.html.twig"));

        $__internal_dfd82683d592f9db10b10c41db88e8458142dee76d8aaef5dff779d90a62a638 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dfd82683d592f9db10b10c41db88e8458142dee76d8aaef5dff779d90a62a638->enter($__internal_dfd82683d592f9db10b10c41db88e8458142dee76d8aaef5dff779d90a62a638_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_91e90bda0a7ca16f8cb5dddd19e462a189fbdbd0e089fe87d0536504b7fdfc59->leave($__internal_91e90bda0a7ca16f8cb5dddd19e462a189fbdbd0e089fe87d0536504b7fdfc59_prof);

        
        $__internal_dfd82683d592f9db10b10c41db88e8458142dee76d8aaef5dff779d90a62a638->leave($__internal_dfd82683d592f9db10b10c41db88e8458142dee76d8aaef5dff779d90a62a638_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_49da50cafaae604ae3c0236b10e8897bd0e1d1d9c038bdba92abb71bda338ff7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_49da50cafaae604ae3c0236b10e8897bd0e1d1d9c038bdba92abb71bda338ff7->enter($__internal_49da50cafaae604ae3c0236b10e8897bd0e1d1d9c038bdba92abb71bda338ff7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ca4df87e8402057941ff8f2a2b4919ee6024b1cd52a350e8d56d0bd5da2fdd3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca4df87e8402057941ff8f2a2b4919ee6024b1cd52a350e8d56d0bd5da2fdd3c->enter($__internal_ca4df87e8402057941ff8f2a2b4919ee6024b1cd52a350e8d56d0bd5da2fdd3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    Ajouter une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_ca4df87e8402057941ff8f2a2b4919ee6024b1cd52a350e8d56d0bd5da2fdd3c->leave($__internal_ca4df87e8402057941ff8f2a2b4919ee6024b1cd52a350e8d56d0bd5da2fdd3c_prof);

        
        $__internal_49da50cafaae604ae3c0236b10e8897bd0e1d1d9c038bdba92abb71bda338ff7->leave($__internal_49da50cafaae604ae3c0236b10e8897bd0e1d1d9c038bdba92abb71bda338ff7_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_685376f73a4dfd3decaae53a5ca6bf73515ef60c2c3e2b97176026158046e1b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_685376f73a4dfd3decaae53a5ca6bf73515ef60c2c3e2b97176026158046e1b5->enter($__internal_685376f73a4dfd3decaae53a5ca6bf73515ef60c2c3e2b97176026158046e1b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_4751c8841917df6748c9118cd3d2d9283ad756d425ef31b9d598e5b79e1be996 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4751c8841917df6748c9118cd3d2d9283ad756d425ef31b9d598e5b79e1be996->enter($__internal_4751c8841917df6748c9118cd3d2d9283ad756d425ef31b9d598e5b79e1be996_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
    <h2>Ajouter une annonce</h2>

    ";
        // line 13
        echo twig_include($this->env, $context, "OCPlatformBundle:Advert:form.html.twig");
        echo "


";
        
        $__internal_4751c8841917df6748c9118cd3d2d9283ad756d425ef31b9d598e5b79e1be996->leave($__internal_4751c8841917df6748c9118cd3d2d9283ad756d425ef31b9d598e5b79e1be996_prof);

        
        $__internal_685376f73a4dfd3decaae53a5ca6bf73515ef60c2c3e2b97176026158046e1b5->leave($__internal_685376f73a4dfd3decaae53a5ca6bf73515ef60c2c3e2b97176026158046e1b5_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 13,  72 => 10,  63 => 9,  50 => 6,  41 => 5,  11 => 3,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/Advert/edit.html.twig #}

{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Ajouter une annonce - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>Ajouter une annonce</h2>

    {{ include(\"OCPlatformBundle:Advert:form.html.twig\") }}


{% endblock %}", "OCPlatformBundle:Advert:add.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/add.html.twig");
    }
}
