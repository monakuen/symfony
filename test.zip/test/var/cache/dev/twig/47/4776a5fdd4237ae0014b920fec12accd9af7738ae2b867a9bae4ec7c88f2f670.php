<?php

/* OCPlatformBundle:Advert:view.html.twig */
class __TwigTemplate_c0434bb3a8a78a016cfe27475d733bdce5b2e721056840ca8b62db771b31391f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_95ec7a23b8da3f0cfcf3c811c93e353784fa9a2bcf8f75597ce7c96f8ee280ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_95ec7a23b8da3f0cfcf3c811c93e353784fa9a2bcf8f75597ce7c96f8ee280ae->enter($__internal_95ec7a23b8da3f0cfcf3c811c93e353784fa9a2bcf8f75597ce7c96f8ee280ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        $__internal_2e64e1f40d1d8c17e298d2564e84c8df52337d63432780345b1d8979c28ea549 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e64e1f40d1d8c17e298d2564e84c8df52337d63432780345b1d8979c28ea549->enter($__internal_2e64e1f40d1d8c17e298d2564e84c8df52337d63432780345b1d8979c28ea549_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:view.html.twig"));

        // line 1
        echo "ceci est la page de l'id : ";
        echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        
        $__internal_95ec7a23b8da3f0cfcf3c811c93e353784fa9a2bcf8f75597ce7c96f8ee280ae->leave($__internal_95ec7a23b8da3f0cfcf3c811c93e353784fa9a2bcf8f75597ce7c96f8ee280ae_prof);

        
        $__internal_2e64e1f40d1d8c17e298d2564e84c8df52337d63432780345b1d8979c28ea549->leave($__internal_2e64e1f40d1d8c17e298d2564e84c8df52337d63432780345b1d8979c28ea549_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("ceci est la page de l'id : {{ id }}", "OCPlatformBundle:Advert:view.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/view.html.twig");
    }
}
