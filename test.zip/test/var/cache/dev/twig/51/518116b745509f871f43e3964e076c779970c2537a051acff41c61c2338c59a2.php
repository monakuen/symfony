<?php

/* OCPlatformBundle:Advert:edit.html.twig */
class __TwigTemplate_611ddff19fba5a9c0bdb27121224125a80e00265c9ea0f5aa2ac7684f3e2fb98 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_270591d2a801412b99f2fb023fd0882456452a285d693bea3f9736b8f25d67c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_270591d2a801412b99f2fb023fd0882456452a285d693bea3f9736b8f25d67c3->enter($__internal_270591d2a801412b99f2fb023fd0882456452a285d693bea3f9736b8f25d67c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:edit.html.twig"));

        $__internal_1ad8bbd219283804c8cfa515d5a34b38f5b2b633136992e691fbc0bdc4595e21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ad8bbd219283804c8cfa515d5a34b38f5b2b633136992e691fbc0bdc4595e21->enter($__internal_1ad8bbd219283804c8cfa515d5a34b38f5b2b633136992e691fbc0bdc4595e21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:edit.html.twig"));

        // line 1
        echo "ceci est la page avec le formulaire pour edit l'id : ";
        echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        
        $__internal_270591d2a801412b99f2fb023fd0882456452a285d693bea3f9736b8f25d67c3->leave($__internal_270591d2a801412b99f2fb023fd0882456452a285d693bea3f9736b8f25d67c3_prof);

        
        $__internal_1ad8bbd219283804c8cfa515d5a34b38f5b2b633136992e691fbc0bdc4595e21->leave($__internal_1ad8bbd219283804c8cfa515d5a34b38f5b2b633136992e691fbc0bdc4595e21_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("ceci est la page avec le formulaire pour edit l'id : {{ id }}", "OCPlatformBundle:Advert:edit.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/edit.html.twig");
    }
}
