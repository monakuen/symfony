<?php

/* OCPlatformBundle:Advert:form.html.twig */
class __TwigTemplate_3ec5e3b6a6e6a742dd31299b25d897a92ea6c3ccb8922d5a1f9879080d02da49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b753f4e63b6f9668e15c079c140ab9cb2cf35c8882be6cd685e3eca97036e866 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b753f4e63b6f9668e15c079c140ab9cb2cf35c8882be6cd685e3eca97036e866->enter($__internal_b753f4e63b6f9668e15c079c140ab9cb2cf35c8882be6cd685e3eca97036e866_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:form.html.twig"));

        $__internal_99ce9587ae1298523d3948e5b0d183970ed78fedee5fbae2505a35e2816df1ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99ce9587ae1298523d3948e5b0d183970ed78fedee5fbae2505a35e2816df1ea->enter($__internal_99ce9587ae1298523d3948e5b0d183970ed78fedee5fbae2505a35e2816df1ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:form.html.twig"));

        // line 2
        echo "
<h3>Formulaire d'annonce</h3>

";
        // line 7
        echo "<div class=\"well\">
    Ici se trouvera le formulaire.
</div>";
        
        $__internal_b753f4e63b6f9668e15c079c140ab9cb2cf35c8882be6cd685e3eca97036e866->leave($__internal_b753f4e63b6f9668e15c079c140ab9cb2cf35c8882be6cd685e3eca97036e866_prof);

        
        $__internal_99ce9587ae1298523d3948e5b0d183970ed78fedee5fbae2505a35e2816df1ea->leave($__internal_99ce9587ae1298523d3948e5b0d183970ed78fedee5fbae2505a35e2816df1ea_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  30 => 7,  25 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/Advert/form.html.twig #}

<h3>Formulaire d'annonce</h3>

{# On laisse vide la vue pour l'instant, on la comblera plus tard
   lorsqu'on saura afficher un formulaire. #}
<div class=\"well\">
    Ici se trouvera le formulaire.
</div>", "OCPlatformBundle:Advert:form.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/form.html.twig");
    }
}
