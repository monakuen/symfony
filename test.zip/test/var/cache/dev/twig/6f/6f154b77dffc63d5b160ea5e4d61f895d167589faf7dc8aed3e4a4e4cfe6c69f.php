<?php

/* @Twig/images/icon-plus-square.svg */
class __TwigTemplate_ff57c058cda98d9aabd1793267914c8b62bcb0f7f38ea3b96bf9702002515345 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4760c788ed39d1f4745a0736b260ec0699209f46e8937294abb687a498778504 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4760c788ed39d1f4745a0736b260ec0699209f46e8937294abb687a498778504->enter($__internal_4760c788ed39d1f4745a0736b260ec0699209f46e8937294abb687a498778504_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        $__internal_f1f0adeda3b131b93e76109c5cc9cb3359a5ce9ab00c035d1a2909bb6b4f2672 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1f0adeda3b131b93e76109c5cc9cb3359a5ce9ab00c035d1a2909bb6b4f2672->enter($__internal_f1f0adeda3b131b93e76109c5cc9cb3359a5ce9ab00c035d1a2909bb6b4f2672_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
";
        
        $__internal_4760c788ed39d1f4745a0736b260ec0699209f46e8937294abb687a498778504->leave($__internal_4760c788ed39d1f4745a0736b260ec0699209f46e8937294abb687a498778504_prof);

        
        $__internal_f1f0adeda3b131b93e76109c5cc9cb3359a5ce9ab00c035d1a2909bb6b4f2672->leave($__internal_f1f0adeda3b131b93e76109c5cc9cb3359a5ce9ab00c035d1a2909bb6b4f2672_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-plus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
", "@Twig/images/icon-plus-square.svg", "/home/jerome/symfony/test/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-plus-square.svg");
    }
}
