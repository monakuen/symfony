<?php

/* OCPlatformBundle:Advert:delete.html.twig */
class __TwigTemplate_9bfdfcb65ac2d182997587c816d21566daa9e5035601295be64dd7d97a710e3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_325a2e749e7e6dbeed7122970963269ae508223cf01a63f1432dd1d7b2b6f86f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_325a2e749e7e6dbeed7122970963269ae508223cf01a63f1432dd1d7b2b6f86f->enter($__internal_325a2e749e7e6dbeed7122970963269ae508223cf01a63f1432dd1d7b2b6f86f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:delete.html.twig"));

        $__internal_240c07419ca29bdad2fbbf86cd83917698a60cbbf83791f3bf454bdf8fe29bb1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_240c07419ca29bdad2fbbf86cd83917698a60cbbf83791f3bf454bdf8fe29bb1->enter($__internal_240c07419ca29bdad2fbbf86cd83917698a60cbbf83791f3bf454bdf8fe29bb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:delete.html.twig"));

        // line 1
        echo "ceci est la page ou on aura supprimé l'id : ";
        echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        
        $__internal_325a2e749e7e6dbeed7122970963269ae508223cf01a63f1432dd1d7b2b6f86f->leave($__internal_325a2e749e7e6dbeed7122970963269ae508223cf01a63f1432dd1d7b2b6f86f_prof);

        
        $__internal_240c07419ca29bdad2fbbf86cd83917698a60cbbf83791f3bf454bdf8fe29bb1->leave($__internal_240c07419ca29bdad2fbbf86cd83917698a60cbbf83791f3bf454bdf8fe29bb1_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("ceci est la page ou on aura supprimé l'id : {{ id }}", "OCPlatformBundle:Advert:delete.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/delete.html.twig");
    }
}
