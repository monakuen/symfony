<?php

/* OCPlatformBundle:Advert:index.html.twig */
class __TwigTemplate_f364da7e62d7794af3c3ba7c8e2728d98fa6791021f299ec9a3bdf9426bc68f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Advert:index.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2494ab773f3c283178fe90fe05007166319e01d947d8cd13b32f78efa7feec20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2494ab773f3c283178fe90fe05007166319e01d947d8cd13b32f78efa7feec20->enter($__internal_2494ab773f3c283178fe90fe05007166319e01d947d8cd13b32f78efa7feec20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:index.html.twig"));

        $__internal_ffad66bf0729c43a374c15146570be82736d1726102e7ef5d8808690b2437f08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffad66bf0729c43a374c15146570be82736d1726102e7ef5d8808690b2437f08->enter($__internal_ffad66bf0729c43a374c15146570be82736d1726102e7ef5d8808690b2437f08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2494ab773f3c283178fe90fe05007166319e01d947d8cd13b32f78efa7feec20->leave($__internal_2494ab773f3c283178fe90fe05007166319e01d947d8cd13b32f78efa7feec20_prof);

        
        $__internal_ffad66bf0729c43a374c15146570be82736d1726102e7ef5d8808690b2437f08->leave($__internal_ffad66bf0729c43a374c15146570be82736d1726102e7ef5d8808690b2437f08_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_823b06304917e61e8813e521b8e4daab14ef320d4ad9377948603ec4cb715f6a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_823b06304917e61e8813e521b8e4daab14ef320d4ad9377948603ec4cb715f6a->enter($__internal_823b06304917e61e8813e521b8e4daab14ef320d4ad9377948603ec4cb715f6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_7e2de030b6c347cea36efc6630188e1008bfe2496fcfdaa4b8cfae50a318bdc7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e2de030b6c347cea36efc6630188e1008bfe2496fcfdaa4b8cfae50a318bdc7->enter($__internal_7e2de030b6c347cea36efc6630188e1008bfe2496fcfdaa4b8cfae50a318bdc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_7e2de030b6c347cea36efc6630188e1008bfe2496fcfdaa4b8cfae50a318bdc7->leave($__internal_7e2de030b6c347cea36efc6630188e1008bfe2496fcfdaa4b8cfae50a318bdc7_prof);

        
        $__internal_823b06304917e61e8813e521b8e4daab14ef320d4ad9377948603ec4cb715f6a->leave($__internal_823b06304917e61e8813e521b8e4daab14ef320d4ad9377948603ec4cb715f6a_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_41b72fd7dd2d95562076761cb9fff15f2558cb71b9a9f544cdcdb0d1a8c3bcb1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41b72fd7dd2d95562076761cb9fff15f2558cb71b9a9f544cdcdb0d1a8c3bcb1->enter($__internal_41b72fd7dd2d95562076761cb9fff15f2558cb71b9a9f544cdcdb0d1a8c3bcb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_026c6c2c905108252ccf0f2a15c09866818ca3aa1fa2f218408d7495a5ea889d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_026c6c2c905108252ccf0f2a15c09866818ca3aa1fa2f218408d7495a5ea889d->enter($__internal_026c6c2c905108252ccf0f2a15c09866818ca3aa1fa2f218408d7495a5ea889d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
    <h2>Liste des annonces</h2>

    <ul>
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listAdverts"]) || array_key_exists("listAdverts", $context) ? $context["listAdverts"] : (function () { throw new Twig_Error_Runtime('Variable "listAdverts" does not exist.', 14, $this->getSourceContext()); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["advert"]) {
            // line 15
            echo "            <li>
                <a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("oc_platform_view", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "id", array()))), "html", null, true);
            echo "\">
                    ";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "title", array()), "html", null, true);
            echo "
                </a>
                par ";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "author", array()), "html", null, true);
            echo ",
                le ";
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["advert"], "date", array()), "d/m/Y"), "html", null, true);
            echo "
            </li>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 23
            echo "            <li>Pas (encore !) d'annonces</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "    </ul>

";
        
        $__internal_026c6c2c905108252ccf0f2a15c09866818ca3aa1fa2f218408d7495a5ea889d->leave($__internal_026c6c2c905108252ccf0f2a15c09866818ca3aa1fa2f218408d7495a5ea889d_prof);

        
        $__internal_41b72fd7dd2d95562076761cb9fff15f2558cb71b9a9f544cdcdb0d1a8c3bcb1->leave($__internal_41b72fd7dd2d95562076761cb9fff15f2558cb71b9a9f544cdcdb0d1a8c3bcb1_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 25,  107 => 23,  99 => 20,  95 => 19,  90 => 17,  86 => 16,  83 => 15,  78 => 14,  72 => 10,  63 => 9,  50 => 6,  41 => 5,  11 => 3,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/Advert/index.html.twig #}

{% extends \"OCPlatformBundle::layout.html.twig\" %}

{% block title %}
    Accueil - {{ parent() }}
{% endblock %}

{% block ocplatform_body %}

    <h2>Liste des annonces</h2>

    <ul>
        {% for advert in listAdverts %}
            <li>
                <a href=\"{{ path('oc_platform_view', {'id': advert.id}) }}\">
                    {{ advert.title }}
                </a>
                par {{ advert.author }},
                le {{ advert.date|date('d/m/Y') }}
            </li>
        {% else %}
            <li>Pas (encore !) d'annonces</li>
        {% endfor %}
    </ul>

{% endblock %}", "OCPlatformBundle:Advert:index.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/index.html.twig");
    }
}
