<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_4e3271903e33ece75271e854a17246dc43a169ac90a69a863843468c5ada6dd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2987f875fcb1539c54ff58f08fd068fb27cfd3cce25bb5433a08f3631f9ccf52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2987f875fcb1539c54ff58f08fd068fb27cfd3cce25bb5433a08f3631f9ccf52->enter($__internal_2987f875fcb1539c54ff58f08fd068fb27cfd3cce25bb5433a08f3631f9ccf52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_f6e593cb11e209834772e265caab0331b41edd1ad5ceacfc3ba2f8193c87f2be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6e593cb11e209834772e265caab0331b41edd1ad5ceacfc3ba2f8193c87f2be->enter($__internal_f6e593cb11e209834772e265caab0331b41edd1ad5ceacfc3ba2f8193c87f2be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2987f875fcb1539c54ff58f08fd068fb27cfd3cce25bb5433a08f3631f9ccf52->leave($__internal_2987f875fcb1539c54ff58f08fd068fb27cfd3cce25bb5433a08f3631f9ccf52_prof);

        
        $__internal_f6e593cb11e209834772e265caab0331b41edd1ad5ceacfc3ba2f8193c87f2be->leave($__internal_f6e593cb11e209834772e265caab0331b41edd1ad5ceacfc3ba2f8193c87f2be_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_7c1c8011a8f1410b3b688ec85165a262e0c758e322ac76315e791145b39a8093 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7c1c8011a8f1410b3b688ec85165a262e0c758e322ac76315e791145b39a8093->enter($__internal_7c1c8011a8f1410b3b688ec85165a262e0c758e322ac76315e791145b39a8093_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_677434bfe379b27ff065f17f3e1c2d6c392ba464c5b63da5d5eeb41e8d494164 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_677434bfe379b27ff065f17f3e1c2d6c392ba464c5b63da5d5eeb41e8d494164->enter($__internal_677434bfe379b27ff065f17f3e1c2d6c392ba464c5b63da5d5eeb41e8d494164_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_677434bfe379b27ff065f17f3e1c2d6c392ba464c5b63da5d5eeb41e8d494164->leave($__internal_677434bfe379b27ff065f17f3e1c2d6c392ba464c5b63da5d5eeb41e8d494164_prof);

        
        $__internal_7c1c8011a8f1410b3b688ec85165a262e0c758e322ac76315e791145b39a8093->leave($__internal_7c1c8011a8f1410b3b688ec85165a262e0c758e322ac76315e791145b39a8093_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_42cc0f33a4d7dc80789406622a6c0a9e3d2edc0b60223abe843d2c3f869d60d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42cc0f33a4d7dc80789406622a6c0a9e3d2edc0b60223abe843d2c3f869d60d2->enter($__internal_42cc0f33a4d7dc80789406622a6c0a9e3d2edc0b60223abe843d2c3f869d60d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_b7cd7188af055b32ccc87a9d8dc9731da7ebbeecd60caaff2cc946cfcba074a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7cd7188af055b32ccc87a9d8dc9731da7ebbeecd60caaff2cc946cfcba074a1->enter($__internal_b7cd7188af055b32ccc87a9d8dc9731da7ebbeecd60caaff2cc946cfcba074a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_b7cd7188af055b32ccc87a9d8dc9731da7ebbeecd60caaff2cc946cfcba074a1->leave($__internal_b7cd7188af055b32ccc87a9d8dc9731da7ebbeecd60caaff2cc946cfcba074a1_prof);

        
        $__internal_42cc0f33a4d7dc80789406622a6c0a9e3d2edc0b60223abe843d2c3f869d60d2->leave($__internal_42cc0f33a4d7dc80789406622a6c0a9e3d2edc0b60223abe843d2c3f869d60d2_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_3b31d614aa2cfa3bc1c547d499f66eb44ada67acd33b5a3c935e5f0848ef25e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b31d614aa2cfa3bc1c547d499f66eb44ada67acd33b5a3c935e5f0848ef25e4->enter($__internal_3b31d614aa2cfa3bc1c547d499f66eb44ada67acd33b5a3c935e5f0848ef25e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_636220d1ccc87b58da2fb2eaf9ec9792e9c6bfd0c33d3ba2a57df5faa243b29e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_636220d1ccc87b58da2fb2eaf9ec9792e9c6bfd0c33d3ba2a57df5faa243b29e->enter($__internal_636220d1ccc87b58da2fb2eaf9ec9792e9c6bfd0c33d3ba2a57df5faa243b29e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_636220d1ccc87b58da2fb2eaf9ec9792e9c6bfd0c33d3ba2a57df5faa243b29e->leave($__internal_636220d1ccc87b58da2fb2eaf9ec9792e9c6bfd0c33d3ba2a57df5faa243b29e_prof);

        
        $__internal_3b31d614aa2cfa3bc1c547d499f66eb44ada67acd33b5a3c935e5f0848ef25e4->leave($__internal_3b31d614aa2cfa3bc1c547d499f66eb44ada67acd33b5a3c935e5f0848ef25e4_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/home/jerome/symfony/test/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
