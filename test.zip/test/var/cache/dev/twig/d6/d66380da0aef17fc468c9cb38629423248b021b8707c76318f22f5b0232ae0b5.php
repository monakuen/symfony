<?php

/* OCPlatformBundle:Advert:index.html.twig */
class __TwigTemplate_9eb3a391e94dabe671ba9d59ef38b5af904aea870763783116206e08416d91a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5261a0d8edce839e96f8c73eafa485d549e0e8b634bfaf8e9099ae2b30fbc723 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5261a0d8edce839e96f8c73eafa485d549e0e8b634bfaf8e9099ae2b30fbc723->enter($__internal_5261a0d8edce839e96f8c73eafa485d549e0e8b634bfaf8e9099ae2b30fbc723_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:index.html.twig"));

        $__internal_377505214da15aac476a7d2d594d0608cfc1710240dd15bab3f0f7c085cd0154 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_377505214da15aac476a7d2d594d0608cfc1710240dd15bab3f0f7c085cd0154->enter($__internal_377505214da15aac476a7d2d594d0608cfc1710240dd15bab3f0f7c085cd0154_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:index.html.twig"));

        // line 2
        echo "
<!DOCTYPE html>
<html>
<head>
    <title>Bienvenue sur ma première page avec OpenClassrooms !</title>
</head>
<body>
<h1>Hello World !</h1>

<p>
    Le Hello World est un grand classique en programmation.
    Il signifie énormément, car cela veut dire que vous avez
    réussi à exécuter le programme pour accomplir une tâche simple :
    afficher ce hello world !
</p>
</body>
</html>
";
        
        $__internal_5261a0d8edce839e96f8c73eafa485d549e0e8b634bfaf8e9099ae2b30fbc723->leave($__internal_5261a0d8edce839e96f8c73eafa485d549e0e8b634bfaf8e9099ae2b30fbc723_prof);

        
        $__internal_377505214da15aac476a7d2d594d0608cfc1710240dd15bab3f0f7c085cd0154->leave($__internal_377505214da15aac476a7d2d594d0608cfc1710240dd15bab3f0f7c085cd0154_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/Advert/index.html.twig #}

<!DOCTYPE html>
<html>
<head>
    <title>Bienvenue sur ma première page avec OpenClassrooms !</title>
</head>
<body>
<h1>Hello World !</h1>

<p>
    Le Hello World est un grand classique en programmation.
    Il signifie énormément, car cela veut dire que vous avez
    réussi à exécuter le programme pour accomplir une tâche simple :
    afficher ce hello world !
</p>
</body>
</html>
", "OCPlatformBundle:Advert:index.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/Advert/index.html.twig");
    }
}
