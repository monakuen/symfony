<?php

/* OCPlatformBundle::layout.html.twig */
class __TwigTemplate_6bb31e474177f4f32fe54330ae9a9083dd82f4af58f0c299ee90a2930fe9f51e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("::layout.html.twig", "OCPlatformBundle::layout.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b02fa03c31ec1a701fd6fa74031e4da7efd9d0ad0ac06a8e527c3741a1498e2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b02fa03c31ec1a701fd6fa74031e4da7efd9d0ad0ac06a8e527c3741a1498e2c->enter($__internal_b02fa03c31ec1a701fd6fa74031e4da7efd9d0ad0ac06a8e527c3741a1498e2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $__internal_c7e69e3d78116ca2c81efbaecbb61e75acb6af7c7643819d2465ba7ab2720125 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7e69e3d78116ca2c81efbaecbb61e75acb6af7c7643819d2465ba7ab2720125->enter($__internal_c7e69e3d78116ca2c81efbaecbb61e75acb6af7c7643819d2465ba7ab2720125_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b02fa03c31ec1a701fd6fa74031e4da7efd9d0ad0ac06a8e527c3741a1498e2c->leave($__internal_b02fa03c31ec1a701fd6fa74031e4da7efd9d0ad0ac06a8e527c3741a1498e2c_prof);

        
        $__internal_c7e69e3d78116ca2c81efbaecbb61e75acb6af7c7643819d2465ba7ab2720125->leave($__internal_c7e69e3d78116ca2c81efbaecbb61e75acb6af7c7643819d2465ba7ab2720125_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_d678e9e9f8daec82f1c358c1338ce708fc32917d7c1fe979d1ad96514907eb9f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d678e9e9f8daec82f1c358c1338ce708fc32917d7c1fe979d1ad96514907eb9f->enter($__internal_d678e9e9f8daec82f1c358c1338ce708fc32917d7c1fe979d1ad96514907eb9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_36938e43a61c7565c5b505e087ffe05c698893c6eaf80281e95e1182c3bf86ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36938e43a61c7565c5b505e087ffe05c698893c6eaf80281e95e1182c3bf86ba->enter($__internal_36938e43a61c7565c5b505e087ffe05c698893c6eaf80281e95e1182c3bf86ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "    Annonces - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_36938e43a61c7565c5b505e087ffe05c698893c6eaf80281e95e1182c3bf86ba->leave($__internal_36938e43a61c7565c5b505e087ffe05c698893c6eaf80281e95e1182c3bf86ba_prof);

        
        $__internal_d678e9e9f8daec82f1c358c1338ce708fc32917d7c1fe979d1ad96514907eb9f->leave($__internal_d678e9e9f8daec82f1c358c1338ce708fc32917d7c1fe979d1ad96514907eb9f_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_2f88a265d7b6e9a07f1693d5f5f50f09534582fac863562579349a63f9b86d5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f88a265d7b6e9a07f1693d5f5f50f09534582fac863562579349a63f9b86d5c->enter($__internal_2f88a265d7b6e9a07f1693d5f5f50f09534582fac863562579349a63f9b86d5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8f43512b190e3f1dd8fef4b3ca60ba0d049fc72020f0ce2e38a4691e13b97aaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f43512b190e3f1dd8fef4b3ca60ba0d049fc72020f0ce2e38a4691e13b97aaa->enter($__internal_8f43512b190e3f1dd8fef4b3ca60ba0d049fc72020f0ce2e38a4691e13b97aaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
    ";
        // line 12
        echo "    <h1>Annonces</h1>

    <hr>

    ";
        // line 17
        echo "    ";
        $this->displayBlock('ocplatform_body', $context, $blocks);
        // line 19
        echo "
";
        
        $__internal_8f43512b190e3f1dd8fef4b3ca60ba0d049fc72020f0ce2e38a4691e13b97aaa->leave($__internal_8f43512b190e3f1dd8fef4b3ca60ba0d049fc72020f0ce2e38a4691e13b97aaa_prof);

        
        $__internal_2f88a265d7b6e9a07f1693d5f5f50f09534582fac863562579349a63f9b86d5c->leave($__internal_2f88a265d7b6e9a07f1693d5f5f50f09534582fac863562579349a63f9b86d5c_prof);

    }

    // line 17
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_79416158245fa2fe938e90d990c9b63c09063390e0256fc8d7451ae875630b1c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79416158245fa2fe938e90d990c9b63c09063390e0256fc8d7451ae875630b1c->enter($__internal_79416158245fa2fe938e90d990c9b63c09063390e0256fc8d7451ae875630b1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        $__internal_a7c1c7b175f1a931ff71934c10f57b4d068d79fd94612cefe38c3cb6b190d7af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7c1c7b175f1a931ff71934c10f57b4d068d79fd94612cefe38c3cb6b190d7af->enter($__internal_a7c1c7b175f1a931ff71934c10f57b4d068d79fd94612cefe38c3cb6b190d7af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 18
        echo "    ";
        
        $__internal_a7c1c7b175f1a931ff71934c10f57b4d068d79fd94612cefe38c3cb6b190d7af->leave($__internal_a7c1c7b175f1a931ff71934c10f57b4d068d79fd94612cefe38c3cb6b190d7af_prof);

        
        $__internal_79416158245fa2fe938e90d990c9b63c09063390e0256fc8d7451ae875630b1c->leave($__internal_79416158245fa2fe938e90d990c9b63c09063390e0256fc8d7451ae875630b1c_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 18,  96 => 17,  85 => 19,  82 => 17,  76 => 12,  73 => 10,  64 => 9,  51 => 6,  42 => 5,  11 => 3,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# src/OC/PlatformBundle/Resources/views/layout.html.twig #}

{% extends \"::layout.html.twig\" %}

{% block title %}
    Annonces - {{ parent() }}
{% endblock %}

{% block body %}

    {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}
    <h1>Annonces</h1>

    <hr>

    {# On définit un nouveau bloc, que les vues du bundle pourront remplir #}
    {% block ocplatform_body %}
    {% endblock %}

{% endblock %}", "OCPlatformBundle::layout.html.twig", "/home/jerome/symfony/test/src/OC/PlatformBundle/Resources/views/layout.html.twig");
    }
}
