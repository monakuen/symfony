<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_4fe0126cea834c2021a568bc22188a6a6babe007ed6f1aff9514e87b8ba11595 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb12443f8f54f9311c1c7a24701bb5fae8dd43cd1a65f98622e1ec81ca93c9db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb12443f8f54f9311c1c7a24701bb5fae8dd43cd1a65f98622e1ec81ca93c9db->enter($__internal_fb12443f8f54f9311c1c7a24701bb5fae8dd43cd1a65f98622e1ec81ca93c9db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_54ce5a8ae04749504c806367934662fec2b8d8e7a2e0a6484cbef969200402f7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54ce5a8ae04749504c806367934662fec2b8d8e7a2e0a6484cbef969200402f7->enter($__internal_54ce5a8ae04749504c806367934662fec2b8d8e7a2e0a6484cbef969200402f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fb12443f8f54f9311c1c7a24701bb5fae8dd43cd1a65f98622e1ec81ca93c9db->leave($__internal_fb12443f8f54f9311c1c7a24701bb5fae8dd43cd1a65f98622e1ec81ca93c9db_prof);

        
        $__internal_54ce5a8ae04749504c806367934662fec2b8d8e7a2e0a6484cbef969200402f7->leave($__internal_54ce5a8ae04749504c806367934662fec2b8d8e7a2e0a6484cbef969200402f7_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_1cffa555a67e4d71e450b63799463348cfdc3ef5490c2a6fb58d3da87387d3e9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cffa555a67e4d71e450b63799463348cfdc3ef5490c2a6fb58d3da87387d3e9->enter($__internal_1cffa555a67e4d71e450b63799463348cfdc3ef5490c2a6fb58d3da87387d3e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_35af100643679a44094df35835ecf2cc9bea312b8080718a0bc265bdf46b3d5f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35af100643679a44094df35835ecf2cc9bea312b8080718a0bc265bdf46b3d5f->enter($__internal_35af100643679a44094df35835ecf2cc9bea312b8080718a0bc265bdf46b3d5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_35af100643679a44094df35835ecf2cc9bea312b8080718a0bc265bdf46b3d5f->leave($__internal_35af100643679a44094df35835ecf2cc9bea312b8080718a0bc265bdf46b3d5f_prof);

        
        $__internal_1cffa555a67e4d71e450b63799463348cfdc3ef5490c2a6fb58d3da87387d3e9->leave($__internal_1cffa555a67e4d71e450b63799463348cfdc3ef5490c2a6fb58d3da87387d3e9_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_ba9ab83d88d771dd0fba306c720f914a0a44a99bb508998b0a0e0af5510e94d8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba9ab83d88d771dd0fba306c720f914a0a44a99bb508998b0a0e0af5510e94d8->enter($__internal_ba9ab83d88d771dd0fba306c720f914a0a44a99bb508998b0a0e0af5510e94d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d52081fd2cd6c4a592da34057a77dd44990e223570d189a72297c9dbd1f64a4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d52081fd2cd6c4a592da34057a77dd44990e223570d189a72297c9dbd1f64a4f->enter($__internal_d52081fd2cd6c4a592da34057a77dd44990e223570d189a72297c9dbd1f64a4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 137, $this->getSourceContext()); })()), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 137, $this->getSourceContext()); })()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 137, $this->getSourceContext()); })()), "html", null, true);
        echo ")
";
        
        $__internal_d52081fd2cd6c4a592da34057a77dd44990e223570d189a72297c9dbd1f64a4f->leave($__internal_d52081fd2cd6c4a592da34057a77dd44990e223570d189a72297c9dbd1f64a4f_prof);

        
        $__internal_ba9ab83d88d771dd0fba306c720f914a0a44a99bb508998b0a0e0af5510e94d8->leave($__internal_ba9ab83d88d771dd0fba306c720f914a0a44a99bb508998b0a0e0af5510e94d8_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_c953c036ca07b45ec4ab21aa60d94bf8c4f33226ea2931c61b1752c1b3268c86 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c953c036ca07b45ec4ab21aa60d94bf8c4f33226ea2931c61b1752c1b3268c86->enter($__internal_c953c036ca07b45ec4ab21aa60d94bf8c4f33226ea2931c61b1752c1b3268c86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_12d5e5b22ec3471aa32cf0451c1254c8e63d229885c966f39fc6e1a429c02789 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12d5e5b22ec3471aa32cf0451c1254c8e63d229885c966f39fc6e1a429c02789->enter($__internal_12d5e5b22ec3471aa32cf0451c1254c8e63d229885c966f39fc6e1a429c02789_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_12d5e5b22ec3471aa32cf0451c1254c8e63d229885c966f39fc6e1a429c02789->leave($__internal_12d5e5b22ec3471aa32cf0451c1254c8e63d229885c966f39fc6e1a429c02789_prof);

        
        $__internal_c953c036ca07b45ec4ab21aa60d94bf8c4f33226ea2931c61b1752c1b3268c86->leave($__internal_c953c036ca07b45ec4ab21aa60d94bf8c4f33226ea2931c61b1752c1b3268c86_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "/home/jerome/symfony/test/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
