<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_2818adb03de0349061047d8de12e1cb1f6b314a5fb9b9431c7361d075fded912 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52f12a10650aefda5d90b3331a1604522a216e1e9f67c7fa72ad99cffa9cb66e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52f12a10650aefda5d90b3331a1604522a216e1e9f67c7fa72ad99cffa9cb66e->enter($__internal_52f12a10650aefda5d90b3331a1604522a216e1e9f67c7fa72ad99cffa9cb66e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_fd38f2d18fd5a7880e5e9ab1ee71704dbfbc8d18eb120c7cad539dc692a52de6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd38f2d18fd5a7880e5e9ab1ee71704dbfbc8d18eb120c7cad539dc692a52de6->enter($__internal_fd38f2d18fd5a7880e5e9ab1ee71704dbfbc8d18eb120c7cad539dc692a52de6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_52f12a10650aefda5d90b3331a1604522a216e1e9f67c7fa72ad99cffa9cb66e->leave($__internal_52f12a10650aefda5d90b3331a1604522a216e1e9f67c7fa72ad99cffa9cb66e_prof);

        
        $__internal_fd38f2d18fd5a7880e5e9ab1ee71704dbfbc8d18eb120c7cad539dc692a52de6->leave($__internal_fd38f2d18fd5a7880e5e9ab1ee71704dbfbc8d18eb120c7cad539dc692a52de6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "/home/jerome/symfony/test/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/chevron-right.svg");
    }
}
